<?php
// Main connection file for both admin & front end
$servername = "localhost:3307"; // server with custom MySQL port
$username = "root"; // username
$password = ""; // password
$dbname = "onlinefoodphp";  // database

// Create connection
$db = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$db) {
    die("Connection failed: " . mysqli_connect_error());
}

echo "Connected successfully";
?>
